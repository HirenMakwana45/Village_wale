import 'package:flutter/material.dart';
import 'package:accordion/accordion.dart';
import "package:accordion/accordion_section.dart";
import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
class cart extends StatelessWidget {
  const cart({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: cart1(),);
  }
}
class cart1 extends StatefulWidget {
  const cart1({Key? key}) : super(key: key);

  @override
  State<cart1> createState() => _cart1State();
}

class _cart1State extends State<cart1> {
  @override
  Widget build(BuildContext context) {
    int _counter = 0;

    void _incrementCounter() {
      setState(() {
        // This call to setState tells the Flutter framework that something has
        // changed in this State, which causes it to rerun the build method below
        // so that the display can reflect the updated values. If we changed
        // _counter without calling setState(), then the build method would not be
        // called again, and so nothing would appear to happen.
        _counter++;
      });
    }
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        leading: IconButton(onPressed: () {},
          icon: Icon(Icons.arrow_back_ios_new, color: Colors.black,),),
        title: Text('Cart', style: TextStyle(color: Colors.black,),),
      ),
      body: SingleChildScrollView(
        child: Container(
          //  color: Color(0xffFCFDFF),
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
          child: Column(
            children: [
              Row(
                children: [
                  Text('Product Summary', style: TextStyle(color: Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: 19),),
                  SizedBox(width: 8,),
                  Text('(2 items)',
                    style: TextStyle(color: Colors.black, fontSize: 16),)
                ],
              ),
              SizedBox(height: 20,),
              ListView.builder(
                  shrinkWrap: true,
                  primary: false,
                  padding: EdgeInsets.all(5),
                  itemCount: 5,
                  itemBuilder: (context, index) => _product()
              ),

              SizedBox(height: 20,),
              Row(
                children: [
                  Text('Subscription Summary', style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: 19),),
                  SizedBox(width: 8,),
                  Text('(1 items)',
                    style: TextStyle(color: Colors.black, fontSize: 16),)
                ],
              ),
              SizedBox(height: 20,),
              ListView.builder(
                  shrinkWrap: true,
                  primary: false,
                  padding: EdgeInsets.all(5),
                  itemCount: 5,
                  itemBuilder: (context, index) => _subscription()
              ),

              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16,),
                    //width: MediaQuery.of(context).size.width,
                    height: 50,
                    padding: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            // blurRadius: 2,
                            spreadRadius: 2,
                            color: Color(0xff85A633),
                          )
                        ]
                    ),

                    child: Row(
                      children: [
                        SizedBox(width: 15,),
                        Image.asset('assets/bag.png'),
                        SizedBox(width: 9,),
                        Text('See Itemes', style: TextStyle(color: Color(
                            0xff85A633), fontSize: 18, fontWeight: FontWeight
                            .w500),),
                        SizedBox(width: 15,),
                        Icon(Icons.chevron_right, color: Color(0xff85A633),),
                        SizedBox(width: 9,)
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 30,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 9),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Select Prefered Date & Time',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),),
                  ],
                ),
              ),
              //  SizedBox(height: 5,),
              Container(
                // height: 48,
                  child:  Accordion(
                      maxOpenSections: 1,
                      headerBackgroundColorOpened: Colors.white,
                      scaleWhenAnimating: true,
                      openAndCloseAnimation: true,
                      headerPadding:
                      const EdgeInsets.symmetric(vertical: 7, horizontal: 15),
                      children: [
                        AccordionSection(
                          isOpen: false,
                          rightIcon: Icon(Icons.arrow_drop_down,color: Colors.black,),
                          leftIcon:CircleAvatar(child: Icon(Icons.calendar_today_outlined,color: Colors.black,) ,backgroundColor: Colors.transparent,),
                          headerBackgroundColor: Colors.white,
                          headerBackgroundColorOpened: Colors.white,
                          header: Text('Saturday 26 March, 2022', style: TextStyle(fontSize: 17,fontFamily: 'Urbanist',color: Color(0Xff2B3448)),),
                          content: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom( //<-- SEE HERE
                                        backgroundColor: Color(0XffFFFFFF),
                                        side: BorderSide(width: 1.0,color: Color(0XffE1DFDD)),
                                      ),
                                      child: Text('08:00 AM - 11:00 AM',),
                                    ),
                                  ),
                                  SizedBox(width: 10,),
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom( //<-- SEE HERE
                                        backgroundColor: Color(0XffFFFFFF),
                                        side: BorderSide(width: 1.0,color: Color(0XffE1DFDD)),
                                      ),
                                      child: Text('11:00 AM - 01:00 PM',style: TextStyle(color: Color(0xff959595)),),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom( //<-- SEE HERE
                                        backgroundColor: Color(0XffFFFFFF),
                                        side: BorderSide(width: 1.0,color: Color(0XffE1DFDD)),
                                      ),
                                      child: Text('01:00 PM - 03:00 PM',style: TextStyle(),),
                                    ),
                                  ),
                                  SizedBox(width: 10,),
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom( //<-- SEE HERE
                                        backgroundColor: Color(0XffFFFFFF),
                                        side: BorderSide(width: 1.0,color: Color(0XffE1DFDD)),
                                      ),
                                      child: Text('03:00 PM - 05:00 PM',style: TextStyle(),),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom( //<-- SEE HERE
                                        backgroundColor: Color(0XffFFFFFF),
                                        side: BorderSide(width: 1.0,color: Color(0XffE1DFDD)),
                                      ),
                                      child: Text('05:00 PM - 07:00 PM',style: TextStyle(),),
                                    ),
                                  ),
                                  SizedBox(width: 10,),
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom( //<-- SEE HERE
                                        backgroundColor: Color(0XffFFFFFF),
                                        side: BorderSide(width: 1.0,color: Color(0XffE1DFDD)),
                                      ),
                                      child: Text('07:00 PM - 09:00 PM',style: TextStyle(),),
                                    ),
                                  ),
                                ],
                              ),


                            ],
                          ),
                          // content: Text(_loremIpsum, style: _contentStyle),
                          // contentHorizontalPadding: 20,
                          // contentBorderWidth: 1,
                          // onOpenSection: () => print('onOpenSection ...'),
                          // onCloseSection: () => print('onCloseSection ...'),
                          contentHorizontalPadding: 0,
                          contentBorderWidth: 0,
                        ),])
              ),
              //  SizedBox(height: 5,),
              Container(
                //  margin: EdgeInsets.symmetric(horizontal: 20),
                height: 55,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 9,vertical: 11),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset('assets/image 65 (Traced).png'),
                              SizedBox(width: 8,),
                              Text('Add to your promocode', style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w500),)
                            ],
                          ),
                        ),
                      ],
                    ),
                    TextButton(onPressed: () {},
                        child: Text('Apply', style: TextStyle(color: Color(
                            0xff85A633),
                            fontSize: 16,
                            fontWeight: FontWeight.w400),))
                  ],
                ),
              ),

              SizedBox(height: 20,),
              Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 2,
                        color: Colors.black12,
                      ),
                    ]
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15, vertical: 15),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Amount to pay', style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              color: Color(0xff8C8C8C))),
                          Text('₹335.00', style: TextStyle(
                              fontWeight: FontWeight.w500, fontSize: 16),),
                        ],
                      ),
                      SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Service fee', style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              color: Color(0xff8C8C8C)),),
                          Text('₹05.00', style: TextStyle(
                              fontWeight: FontWeight.w500, fontSize: 16),)
                        ],
                      ),
                      SizedBox(height: 8,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Discount', style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              color: Color(0xff8C8C8C))),
                          Text('₹40.00', style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                              color: Color(0xff85A633)),)
                        ],
                      ),
                      Divider(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Total', style: TextStyle(
                            fontWeight: FontWeight.w500, fontSize: 16,)),
                          Text('₹300.00', style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                              color: Color(0xff85A633)),)
                        ],
                      ),
                      SizedBox(height: 5,),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffFCDA28),
                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8))
                ),
                height: 50,
                width: double.infinity,

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset('assets/Group 37736.png'),
                    Text('You have saved ₹100 on this order',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w500),)
                  ],
                ),
              ),
              SizedBox(height: 20,),
              Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: [
                      BoxShadow(
                        //  blurRadius: 2,
                        spreadRadius: 2,
                        color: Color(0xff85A633),
                      )
                    ]
                ),
                child: Column(
                  children: [
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 17,),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Delievred To', style: TextStyle(
                                  fontWeight: FontWeight.w500, fontSize: 16),),
                              TextButton(onPressed: () {}, child: Text('Change',
                                style: TextStyle(color: Color(0xff85A633)),))
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10,),
                          child: Row(
                            children: [
                              Icon(Icons.location_on_outlined),
                              SizedBox(width: 8,),
                              Text(
                                  'B3 205, Nano city, Scheme 114 part 2, \nIndore, MP, 452010')
                            ],
                          ),
                        ),
                        SizedBox(height: 15,),
                        Container(
                          height: 65,
                          color: Color(0xff85A633),
                          width: double.infinity,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 15, vertical: 10),

                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Grand Total',
                                      style: TextStyle(color: Color(0xffBDD879)),),
                                    Text('₹300',
                                      style: TextStyle(color: Colors.white),)
                                  ],
                                ),
                                Container(
                                  //margin: EdgeInsets.symmetric(vertical: 5),
                                  height: 70,
                                  width: 130,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8)
                                  ),

                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('Buy now'),
                                          Text('₹300', style: TextStyle(
                                              color: Color(0xff85A633)),)

                                        ],
                                      ),
                                      SizedBox(width: 15,),
                                      Icon(Icons.arrow_right_alt_rounded,color: Color(0xff85A633),)
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),

              )
            ],
          ),
        ),
      ),
    );
  }


  _product() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5),
      width: double.infinity,
      // height: 105,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4),
        // boxShadow:  [
        //   BoxShadow(
        //     blurRadius: 2,
        //     color: Colors.black12,
        //   )
        // ]
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 5),
        child: Row(
          children: [
            Image.asset('assets/image 40.png', scale: 0.9,),
            SizedBox(width: 5,),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Swadist Soyabean Oil',
                    style: TextStyle(color: Colors.black, fontSize: 18),),
                  // SizedBox(height: 8,),
                  Text('1 ltr',
                    style: TextStyle(color: Color(0xff8C8C8C,), fontSize: 16),),
                  SizedBox(height: 5,),
                  Row(
                    children: [
                      GestureDetector(
                        child: Image.asset('assets/Group 76.png'),),
                      SizedBox(width: 8,),
                      Text('1', style: TextStyle(fontSize: 20),),
                      SizedBox(width: 8,),
                      Image.asset('assets/Group 75.png')
                      // GestureDetector(
                      //   child: CircleAvatar(
                      //     backgroundColor: Color(0xff85A633),
                      //     child: Image.asset('assets/Group 75.png')
                      //   ),
                      // )
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(width: 12,),
            Row(
              children: [
                Icon(Icons.currency_rupee, size: 15, color: Color(0xff85A633),),
                Text('190.00', style: TextStyle(fontSize: 18,
                    color: Color(0xff85A633),
                    fontWeight: FontWeight.w500),),
              ],
            )
          ],
        ),
      ),
    );
  }
}

_subscription(){
  return Container(
    margin: EdgeInsets.symmetric(vertical: 5),
    //height: 170,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(4),
      // boxShadow: [
      //   BoxShadow(
      //     blurRadius: 2,
      //     color: Colors.black12,
      //   )
      // ]
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: 9, vertical: 9),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Image.asset('assets/image 43.png'),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tomato', style: TextStyle(fontSize: 16,
                          fontWeight: FontWeight.w400),),
                      SizedBox(height: 4,),
                      Image.asset('assets/Group 85.png'),
                      SizedBox(height: 4,),
                      Text('1kg',
                        style: TextStyle(color: Color(0xff8C8C8C)),)
                    ],
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Image.asset('assets/Group 37743.png'),
                  Row(
                    children: [
                      Icon(Icons.currency_rupee, size: 15,
                        color: Color(0xff85A633),),
                      Text('190.00', style: TextStyle(fontSize: 18,
                          color: Color(0xff85A633),
                          fontWeight: FontWeight.w500),),
                    ],
                  )

                ],
              )
            ],
          ),
          SizedBox(height: 15,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.shopping_bag_outlined),
                  Text('Quantity per day', style: TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w400),),
                ],
              ),
              // Row(
              //   children: [
              //     GestureDetector(
              //       child: Container(
              //         decoration: BoxDecoration(
              //             color: Colors.white,
              //             borderRadius: BorderRadius.circular(30),
              //             boxShadow: [
              //               BoxShadow(
              //                 //  blurRadius: 2,
              //                 spreadRadius: 2,
              //                 color: Color(0xff85A633),
              //               )
              //             ]
              //         ),
              //         child: CircleAvatar(
              //             backgroundColor: Colors.transparent,
              //             radius: 17,
              //             child: Text('-',style: TextStyle(fontSize:30, color: Color(0xff85A633),),)),
              //       ),),
              //     SizedBox(width: 8,),
              //     Text('1', style: TextStyle(fontSize: 20),),
              //     SizedBox(width: 8,),
              //     GestureDetector(
              //       child: CircleAvatar(
              //         backgroundColor: Color(0xff85A633),
              //         child: Icon(Icons.add, color: Colors.white,),
              //       ),
              //     )
              //   ],
              // ),
              Row(
                children: [
                  GestureDetector(
                    child: Image.asset('assets/Group 76.png'),),
                  SizedBox(width: 8,),
                  // Text(  '$_counter',
                  //   style: Theme.of(context).textTheme.headline4),
                  SizedBox(width: 8,),
                  GestureDetector(
                      onTap: (){
                        _incrementCounter;
                      },
                      child: Image.asset('assets/Group 75.png'))
                  // GestureDetector(
                  //   child: CircleAvatar(
                  //     backgroundColor: Color(0xff85A633),
                  //     child: Image.asset('assets/Group 75.png')
                  //   ),
                  // )
                ],
              ),
            ],
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Repeat', style: TextStyle(
                  fontWeight: FontWeight.w500, fontSize: 18),),
              Container(
                height: 32,
                width: 63,
                padding: EdgeInsets.all(2),
                decoration: BoxDecoration(
                    color: Color(0xff85A633),
                    borderRadius: BorderRadius.circular(18)
                ),
                child: Center(child: Text('Daily',style: TextStyle(color: Colors.white),)),

                // child: ElevatedButton(
                //
                //   onPressed: () {},
                //   child: Center(
                //     child: Text(
                //       'Daily',
                //       style: TextStyle(
                //           fontSize: 15,
                //           color: const Color(0xffffffff),
                //           fontWeight: FontWeight.w600),
                //     ),
                //   ),
                // ),
              )
            ],
          ),

        ],
      ),
    ),

  );
}

void _incrementCounter() {

}

